package com.example.spotifyclone.album_ids.ui;

import com.example.spotifyclone.album_ids.model.Album;


public interface OnAlbumItemClickListener {
     void OnItemClick(Album album);
}
