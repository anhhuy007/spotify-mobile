package com.example.spotifyclone.features.player.model.playlist;

public enum RepeatMode {
    REPEAT_OFF, REPEAT_INFINITE
//    , REPEAT_ONE
}
