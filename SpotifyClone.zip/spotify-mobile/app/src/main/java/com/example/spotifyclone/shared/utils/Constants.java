package com.example.spotifyclone.shared.utils;

public class Constants {
    public  static String userID = "1";
    public  static String userName = "No account";
    public  static String userAvatar = "https://loremflickr.com/640/480/fashion";
    public  static boolean isPremium = false;
}
