package com.example.spotifyclone.features.player.model.playlist;

public enum ShuffleMode {
    SHUFFLE_OFF, SHUFFLE_ON
//    ,SHUFFLE_AI
}
