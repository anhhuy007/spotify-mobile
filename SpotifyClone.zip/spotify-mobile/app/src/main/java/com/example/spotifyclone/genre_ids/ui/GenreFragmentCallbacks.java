package com.example.spotifyclone.genre_ids.ui;

import com.example.spotifyclone.genre_ids.model.Genre;

public interface GenreFragmentCallbacks {
    public void onMsgFromMainToFragment(Genre genre);
}
