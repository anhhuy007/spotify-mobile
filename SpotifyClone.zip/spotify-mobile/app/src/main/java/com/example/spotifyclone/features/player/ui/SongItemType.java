package com.example.spotifyclone.features.player.ui;

public enum SongItemType {
    HORIZONTAL,
    VERTICAL
}
