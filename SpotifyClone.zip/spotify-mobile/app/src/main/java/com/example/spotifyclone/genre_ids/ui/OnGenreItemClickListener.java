package com.example.spotifyclone.genre_ids.ui;

import com.example.spotifyclone.genre_ids.model.Genre;

public interface OnGenreItemClickListener {
    void OnItemClick(Genre genre);
}
