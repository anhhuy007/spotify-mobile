package com.example.spotifyclone.shared.utils;

public class SharedPref {
}
